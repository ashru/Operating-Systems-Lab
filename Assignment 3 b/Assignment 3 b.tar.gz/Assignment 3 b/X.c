#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>	/* Include this to use semaphores */
#include <sys/shm.h>	
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>


#define wait_sem(s) semop(s, &pop, 1)  /* pop is the structure we pass for doing
				   the P(s) operation */
#define signal_sem(s) semop(s, &vop, 1)  /* vop is the structure we pass for doing
				   the V(s) operation */
struct sembuf pop, vop ;


int mutex ;// the semaphore
typedef struct      //Structure Definition for Student abstract data type
{
	char fname[20];
	char lname[20];
	int roll;
	float cgpa;
} Student;
int shared_db,shared_flag,shared_total;// the shared variables

int main(int argc, char *argv[])
{
	//printf("here\n");
	if (argc != 2)
	{
		printf("usage: X <filename>\n");
		exit(-1);
	}

	FILE *file;
	file = fopen(argv[1], "r");//open file in read mode
	if(!file)//if error occurs
		perror("Error in opening file in read mode");
	
	

	//shared memory storing file content
	shared_db = shmget(ftok(".",1), 100*sizeof(Student), 0777|IPC_CREAT|IPC_EXCL);
	if(shared_db==-1)
	{
		perror("Error in getting shmget");
		exit(0);
	}
	// shared memory for flag to check if shared memory was modified
	shared_flag= shmget(ftok(".",2), 1*sizeof(int), 0777|IPC_CREAT|IPC_EXCL);
	if(shared_flag==-1)
	{
		perror("Error in getting shmget");
		exit(0);
	}
	//shared memory for no of student records
	shared_total= shmget(ftok(".",3), 1*sizeof(int), 0777|IPC_CREAT|IPC_EXCL);
	if(shared_total==-1)
	{
		perror("Error in getting shmget");
		exit(0);
	}
	Student *store=(Student *)shmat(shared_db,0,0); // attach shared memory to struct store
	if(store==(Student *)-1)
	{
		perror("Error in shmat");
	}
	int *my_flag=(int *)shmat(shared_flag,0,0); // attach to shared memory to flag
	if(my_flag==(int *)-1)
	{
		perror("Error in shmat");
	}
	my_flag[0]=0;

	int *my_total=(int *)shmat(shared_total,0,0); // attach shared memory to number of students
	if(my_total==(int *)-1)
	{
		perror("Error in shmat");
	}
	//file read
	my_total[0]=0;
	char str[20];int i=0;
	while(fscanf(file,"%s",store[i].fname)>0)//read from file
	{
		fscanf(file,"%s",store[i].lname);
		fscanf(file,"%d",&store[i].roll);
		fscanf(file,"%f",&store[i].cgpa);
		++i;
		if(i==100)//max 100 records
			break;
		++my_total[0];

	}
		fclose(file);

	
	//semaphore mutex created
	if((mutex = semget(ftok(".",4), 1, 0777|IPC_CREAT|IPC_EXCL))==-1) //create semaphore
	{
		perror("Error in creation of semaphore");
		exit(0);
	}
	//	printf("\n\nX sleeps\n\n");

	//sleep(5);
	if(semctl(mutex, 0, SETVAL, 1)==-1)                      //initialize semaphore
		perror("Error in initialization of semaphore");;
	//printf("X initialized\n\n");
	pop.sem_num = vop.sem_num = 0;              // define operations wait and signal
	pop.sem_flg = vop.sem_flg = 0;
	pop.sem_op = -1 ; vop.sem_op = 1 ;
	while(1)
	{
		
		sleep(5);   //sleep for 5 s
		wait_sem(mutex);    //entry point of critical section(acquire semaphore)
		if(my_flag[0]==1)         //if flag is 1 then some modification has occured
		{
			file = fopen(argv[1],"w");        // open file to write
			
			if(!file)
				printf("Error in opening file in write mode %s",argv[1]);
			int i=0;
			while(i<my_total[0])    //write to file
			{
				fprintf(file,"%s %s %d %f\n",store[i].fname,store[i].lname,store[i].roll,store[i].cgpa);
				++i;
			}
			fclose(file);
			my_flag[0]=0;//writing done, flag set back to zero
			
		}
		signal_sem(mutex);//  exit section release semaphore
	}
	shmdt(store); //detach  shared memory
	shmdt(my_flag);
	shmdt(my_total);
	shmctl(shared_db, IPC_RMID, 0);//delete semaphore and shared memory
	shmctl(shared_flag, IPC_RMID, 0);
	shmctl(shared_total, IPC_RMID, 0);
	semctl(mutex, IPC_RMID, 0);

	



	

}