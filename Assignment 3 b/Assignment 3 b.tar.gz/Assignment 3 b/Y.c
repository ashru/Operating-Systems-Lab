#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>	/* Include this to use semaphores */
#include <sys/shm.h>	
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

#define wait_sem(s) semop(s, &pop, 1)  /* pop is the structure we pass for doing
				   the P(s) operation */
#define signal_sem(s) semop(s, &vop, 1)  /* vop is the structure we pass for doing
				   the V(s) operation */
struct sembuf pop, vop ;

union semun {
               int val;
               struct semid_ds *buf;        
               ushort *array;
               struct seminfo  *__buf;
          };//union required for semctl call
int mutex ;  // semaphore id
typedef struct 
{
	char fname[20];                //structure for record
	char lname[20];
	int roll;
	float cgpa;
} Student;
int shared_db,shared_flag,shared_total,shared;  // shared memory id


int main()
{
	
	union semun args;
    struct semid_ds mysemid_ds;
    time_t lock;
	while(mutex = semget(ftok(".",4), 1, 0777)<0)//busy wait till process x has created the semaphore mutex
	{
		printf("Waiting for process X...\n");
	}
	

	mutex = semget(ftok(".",4), 1, 0777);// get semaphore after it is created

	 
    args.buf = &mysemid_ds;
    semctl(mutex,0,IPC_STAT,args);//obtain statistics of semaphore
    
    

	while(args.buf->sem_otime == 0)//busy wait till semaphore not initialized(after creation it may not be initialized, hence wait)
	{
		semctl(mutex, 0,IPC_STAT,args);  //obtain semaphore statistics
		
		printf("Waiting for process X(semaphore not yet initialized)...\n");
	}
	pop.sem_num = vop.sem_num = 0;              // define operations wait and signal
	pop.sem_flg = vop.sem_flg = 0;
	pop.sem_op = -1 ; vop.sem_op = 1 ;
	//shared memorystoring file content
	shared_db = shmget(ftok(".",1), 100*sizeof(Student), 0777);
	// shared memory for flag to check if shared memory was modified
	shared_flag= shmget(ftok(".",2), 1*sizeof(int), 0777);
	//shared no of student records
	shared_total= shmget(ftok(".",3), 1*sizeof(int), 0777);
	Student *store=(Student *)shmat(shared_db,0,0); // attach shared memory to record
	int *my_flag=(int *)shmat(shared_flag,0,0); // attach shared memory to flag (used to check whether shared record has been modified)
	int *my_total=(int *)shmat(shared_total,0,0); // shared total no of records
		

	while(1)
	{
		printf("Press 1 to search for a student record by rollno\n Press 2 to update the CGPA of a particular student\n Press any other number to exit\n");// for different queries
		int ch;
		scanf("%d",&ch);
		if(ch==1)// if choice is search
		{
			int s,i;
			printf("Enter Roll number\n");
			scanf("%d",&s);
			wait_sem(mutex);//entry section acquire semaphore
			int flag=0;//flag for search if found set to 1
			for(i=0;i<my_total[0];++i)
			{
				if(store[i].roll==s)
				{
					flag=1;
					printf("Relevant Student Record:\nFirst name=%s\nLast name=%s\nRoll number=%d\nCGPA=%f\n",store[i].fname,store[i].lname,store[i].roll,store[i].cgpa);
					break;
				}

			}
			if(flag==0)// if not found declare not found
			{
				printf("Record not found!\n");
			}
			signal_sem(mutex); // exit section release semaphore
		}
		else if(ch==2)//if choice is update cgpa
		{
			int s,i;
			printf("Enter Roll number\n");
			scanf("%d",&s);
			wait_sem(mutex);//entry section acquire semaphore
			
			int flag=0;//for searching appropriate roll no
			for(i=0;i<my_total[0];++i)
			{
				if(store[i].roll==s)// if found update cgpa
				{
					flag=1;
					printf("Enter new value of CGPA=");
					float f;
					scanf("%f",&f);
					store[i].cgpa=f;
					my_flag[0]=1;
					break;
				}

			}
			if(flag==0)
			{
				printf("Record not found!\n");
			}	
			signal_sem(mutex);//exit section  release semaphore
		}
		else
		{
			shmdt(store);// detach shared variables from memory
			shmdt(my_flag);
			shmdt(my_total);

			exit(0);
		}
	}


	return 0;
}
