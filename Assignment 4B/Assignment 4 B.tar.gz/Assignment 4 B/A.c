#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>	/* Include this to use semaphores */
#include <sys/shm.h>	
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#define MAX 10
                       
#define wait_sem(s) semop(s, &pop, 1)  /* pop is the structure we pass for doing
				   the wait(s) operation */
#define signal_sem(s) semop(s, &vop, 1)  /* vop is the structure we pass for doing
				   the signal(s) operation */


int full, empty,mutex ;
int buffer_index,shared_buffer,flgB;

struct sembuf pop, vop ;


union semun {
               int val;
               struct semid_ds *buf;        
               ushort *array;
               struct seminfo  *__buf;
          };//union required for semctl call


void my_handler(int signum)//signal handler for sigint and sigusr1used for killing A when B is killed
{
	if(signum==SIGINT)//if ^C is pressed, A must clear all shared memory and semaphore
	{

		printf("Received a SIGINT, exiting process A\n");
		semctl(full, 0, IPC_RMID, 0);//remove semaphores and shared memory
		semctl(empty, 0, IPC_RMID, 0);
		semctl(mutex, 0, IPC_RMID, 0);
		shmctl(shared_buffer, IPC_RMID, 0);
		shmctl(buffer_index, IPC_RMID, 0);
		shmctl(flgB, IPC_RMID, 0);
		
		exit(-1);
	}
	

}



int main()
{
	srand(time(NULL));// seed for random generator
	signal(SIGINT, my_handler);//use custom handler for^C
	shared_buffer = shmget(ftok(".",1), MAX*sizeof(int), 0777|IPC_CREAT|IPC_EXCL);//shared memory for buffer
	// shared memory for index of buffer
	buffer_index = shmget(ftok(".",2), 1*sizeof(int), 0777|IPC_CREAT|IPC_EXCL);//shared memory to store current buffer index
	flgB = shmget(ftok(".",6), 1*sizeof(pid_t), 0777|IPC_CREAT|IPC_EXCL);// shared memory to check if B is running.it is set to 1 if b exits
	//create semaphores full, empty and mutuallyexclusive
	full = semget(ftok(".",3), 1, 0777|IPC_CREAT|IPC_EXCL);// semaphore full to denote how many slots are full
	empty = semget(ftok(".",4), 1, 0777|IPC_CREAT|IPC_EXCL);// semaphore empty to denote how many slots are empty
	int *index = (int *)shmat(buffer_index,0,0);// attach shared variables
	int *mybuf = (int *)shmat(shared_buffer,0,0);
	int *p=(int *)shmat(flgB,0,0);
	//printf("%d\n",buffer_index);
	*index=0;//B if created is waiting on for mutex to be created,hence it does not get to access index
	*p=0;

	
	pop.sem_num = vop.sem_num = 0;              // define operations wait and signal
	pop.sem_flg = vop.sem_flg = 0;
	pop.sem_op = -1 ; vop.sem_op = 1 ;
	
	
	semctl(full, 0, SETVAL, 0);// init full to 0
	semctl(empty, 0, SETVAL, MAX);// init empty to no of max variables in buffer
	mutex = semget(ftok(".",5), 1, 0777|IPC_CREAT|IPC_EXCL);// create semaphore mutex
   	semctl(mutex, 0, SETVAL, 1);// init mutex to 1
   	    
	
	while(1)
	{
		int r=rand()%3;
		sleep(r);// sleep bet 0-2 s
		int no=(rand()%11)-5;// generate a number between -5 to +5
		//standard producer code
		wait_sem(empty);//wait to enter CS
		wait_sem(mutex);//wait to edit buffer
		//write i to buffer,increment index
		
		mybuf[index[0]]=no;// add new request


		
		index[0]++;// increment index
		//printf("%d %d\n",mybuf[index[0]-1],index[0]);
		
		if(*p==1)// indicates b has exit
			break;
		signal_sem(mutex);// signal mutex
		signal_sem(full);// signal full



	}
	shmdt(index);//detach memory
	shmdt(mybuf);// detach memory
	shmdt(p);
	printf("Killing process A as process B is killed\n");
	//first clear up all shared memory and semaphore
	semctl(full, 0, IPC_RMID, 0);//remove semaphores and shared memory
	semctl(empty, 0, IPC_RMID, 0);
	semctl(mutex, 0, IPC_RMID, 0);
	shmctl(shared_buffer, IPC_RMID, 0);
	shmctl(buffer_index, IPC_RMID, 0);
	shmctl(flgB, IPC_RMID, 0);
	exit(-1);

	
}