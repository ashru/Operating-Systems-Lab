#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>	/* Include this to use semaphores */
#include <sys/shm.h>	
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>

#define MAX 10
#define ALLOW 5   //no of threads when consumer wakes up again after going to sleep on getting MAX threads
                       
#define wait_sem(s) semop(s, &pop, 1)  /* pop is the structure we pass for doing
				   the wait(s) operation */
#define signal_sem(s) semop(s, &vop, 1)  /* vop is the structure we pass for doing
				   the signal(s) operation */


int full, empty,mutex ;
int buffer_index,shared_buffer,flgB;
struct sembuf pop, vop ;
pthread_mutex_t mutex1;// for global_counter
pthread_mutex_t mutex2;// for ticket variable
pthread_cond_t condition_var;// for global_counter
pthread_t *threads;
int *thread_flags;// array to kee track of indices of alive threads
union semun {
               int val;
               struct semid_ds *buf;        
               ushort *array;
               struct seminfo  *__buf;
          };//union required for semctl call




int global_counter,ticket;
struct thread_data
{
	int val;
	int index;
};
// structure to pass status info of thread
struct thread_status {
	int status;
	
};
struct thread_data *TD;

void *process_helper(void *parameter)
{
	struct thread_data *t=(struct thread_data *)(parameter);//thread data
	struct thread_status *stat;
	stat = (struct thread_status *)malloc(sizeof(struct thread_status));

	int x=(*t).val;//value of request
	int index=(*t).index;// index of thread
	int *retval=(int *)malloc(1*sizeof(int));// return value
	pthread_mutex_lock(&mutex2);//acquire mutex for ticket variable
	//printf("global=%d x=%d index=%d\n",global_counter,x,index);
	if(ticket-x>=0)
	{
		int s=ticket-x;
		ticket=s<100?s:100;//ticket=min(ticket-x,100)
		stat->status=1;
		int r=rand()%3;
		sleep(r);// sleep for 0-2 sec
		printf("Ticket=%d\n",ticket);
	}
	else
	{
		int r=rand()%3;
		sleep(r);// sleep for 0-2 sec
		printf("Request cannot be fulfilled!!!\n ");
		stat->status=0;

	}
	
	pthread_mutex_unlock(&mutex2);//signal mutex for ticket variable
	pthread_mutex_lock(&mutex1);//acquire mutex1
	global_counter--;//decrement global

	thread_flags[index]=0;//indicate this slot is empty
	if(global_counter<=ALLOW)
		pthread_cond_signal(&condition_var);//if global comes to less than MAX  signal B
	pthread_mutex_unlock(&mutex1);//signal mutex1
	pthread_exit((void *) stat);

}

void my_handler(int signum)
{

	// action if SIGINT
	if (signum == SIGINT)
	{
		printf("PROCESS B: Received SIGINT, exiting ..\n");
		
		semctl(full, 0, IPC_RMID, 0);//remove semaphores and shared memory
		semctl(empty, 0, IPC_RMID, 0);
		semctl(mutex, 0, IPC_RMID, 0);
		shmctl(shared_buffer, IPC_RMID, 0);
		shmctl(buffer_index, IPC_RMID, 0);
		pthread_mutex_destroy(&mutex1);
		pthread_mutex_destroy(&mutex2);
		pthread_cond_destroy(&condition_var);

		int *o=shmat(flgB,0,0);
		if(o!=(void *)-1)// set value of flgB to 1 on B's exit
		{	
			o[0]=1;
			shmdt(o);
		}

		// then exit	
		exit(0);
	}
	
}


int main()
{
	srand(time(NULL));
	signal(SIGINT, my_handler);
	while(mutex = semget(ftok(".",5), 1, 0777)==-1);
		//printf("Waiting1...");
	mutex = semget(ftok(".",5), 1, 0777);
	union semun args;
    struct semid_ds mysemid_ds;
	time_t lock;
	args.buf = &mysemid_ds;
    semctl(mutex,0,IPC_STAT,args);//obtain statistics of semaphore
    //printf("%d \n",args.buf->sem_otime);
	while(args.buf->sem_otime == 0)//busy wait till semaphore not initialized(after creation it may not be initialized, hence wait)
	{
		semctl(mutex, 0,IPC_STAT,args);  //obtain semaphore statistics
		
		//printf("%d\n",args.buf->sem_otime );
	}
	//printf("hey\n\n");
	// shared memory for buffer
	shared_buffer = shmget(ftok(".",1), MAX*sizeof(int), 0777);
	// shared memory for index of buffer
	buffer_index = shmget(ftok(".",2), 1*sizeof(int), 0777);
	// shared memory for process id of A
	flgB = shmget(ftok(".",6), 1*sizeof(pid_t), 0777);

	//semaphores full, empty and mutuallyexclusive
	full = semget(ftok(".",3), 1, 0777);
	empty = semget(ftok(".",4), 1, 0777);
	
	pop.sem_num = vop.sem_num = 0;              // define operations wait and signal
	pop.sem_flg = vop.sem_flg = 0;
	pop.sem_op = -1 ; vop.sem_op = 1 ;

	
	ticket=100;
	int *index =(int *) shmat(buffer_index,0,0);
	int *mybuf =(int *) shmat(shared_buffer,0,0);
	TD=(struct thread_data *)(malloc(MAX*sizeof(struct thread_data)));
	
	thread_flags=(int *)(malloc((MAX+1)*sizeof(int)));
	threads=(pthread_t *)(malloc((MAX+1)*sizeof(pthread_t)));
	for(int i1=0;i1<MAX;++i1)
		thread_flags[i1]=0;

	while(1)
	{
		
		wait_sem(full);
		//printf("In full\n\n");
		wait_sem(mutex);
		//decrement index
		
		
		index[0]--;
		int k;
		if(index[0]>=0)
		 k = mybuf[index[0]];// read value at index
		else continue;
		//printf("%d %d\n",k,index[0]);
		//action
		pthread_mutex_lock(&mutex1);//pthread mutex wait
		if(global_counter>MAX)//check if global==10
		{
			while(global_counter>ALLOW)// wait till no of threads comed down to <=5
			pthread_cond_wait(&condition_var, &mutex1);//if yes wait
		}
		global_counter++;
		//printf("gc=%d\n",global_counter);
		int i1=0;
		while(thread_flags[i1])//find empty index
			++i1;
		thread_flags[i1]=1;// set the thread flag to 1(it will be alive now)
		TD[i1].val=k;// set thread value(same as request value) and index
		TD[i1].index=i1;
		
		pthread_create(&threads[i1], NULL, process_helper, (void *) &TD[i1]);//create thread,send k as parameter

		pthread_mutex_unlock(&mutex1);//pthread mutex signal
		signal_sem(mutex);
		signal_sem(empty);
	}
	shmdt(index);//detach memory
	shmdt(mybuf);
	
}